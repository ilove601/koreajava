package com.example.g5.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MyDiet extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_diet);
        Button restart=findViewById(R.id.goStart);

        restart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"메인화면으로 돌아갑니다",Toast.LENGTH_SHORT).show();
                Intent back = new Intent(getApplicationContext(),MainActivity.class);
                startActivity(back);
            }
        });

        Button concrete = findViewById(R.id.concrete);

        concrete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"자세히 알아보자",Toast.LENGTH_SHORT).show();
                Intent con = new Intent(getApplicationContext(),Plan4Activity.class);
                startActivity(con);
            }
        });

        Button plan = findViewById(R.id.plan);

        plan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"운동은 무얼하나",Toast.LENGTH_SHORT).show();
                Intent p = new Intent(getApplicationContext(),PlanActivity.class);
                startActivity(p);
            }
        });




    }
}
