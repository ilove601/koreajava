package com.example.g5.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //1. 처리할 버튼을 찾으세요. res는 자원들을 의미하고 이를 관리하는 부품은 R이라고 한다.
        Button restart                      =        findViewById(R.id.restart);
        //↑restart라는 명령을 정의하는디            //↑찾아서 던져줍니다.         ▶ 리스타트라는 버튼을 인식하게 된다.

        //2. 버튼을 클릭했을 때 처리할 행동을 setting
        restart.setOnClickListener(new View.OnClickListener() {
            //↑리스타트 버튼이 클릭하기를 기다린다.
            @Override
            public void onClick(View v) {
                //3. 우선 버튼 눌렀을 때 팝업(토스트)을 띄워줘보자
                Toast.makeText(getApplicationContext(),"You clicked the button!",Toast.LENGTH_SHORT).show();
                            //↑알아서 자기의 위치를 알게하고. ↑텍스트는 이걸 띄우되     ↑노출시간 정의    ↑보여줘

        //3. 처리할 행동이란 여기서 DietActivity를 열게 한다.

//                액티비티를 넘길때는...
//                3-1) 액티비티를 넘길 수 있는 부품을 세팅.

//                intent라는 부품을 복사해서 가져와야 한다.
//                3-2) 현재액티비티 --> 가야 할 액티비티 세팅
                 Intent go = new Intent(getApplicationContext(), MyDiet.class);
//
//                3-3) intent 부품 시작
                startActivity(go);

            }
        });







    }
}
