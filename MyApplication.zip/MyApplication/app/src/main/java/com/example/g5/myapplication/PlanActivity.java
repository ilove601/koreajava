package com.example.g5.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class PlanActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_plan);


        Button back = findViewById(R.id.button6);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"뒤로가기",Toast.LENGTH_SHORT).show();
                Intent back2 = new Intent(getApplicationContext(),MyDiet.class);
                startActivity(back2);
            }
        });


//
//        Button concrete = findViewById(R.id.concrete);
//
//        concrete.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Toast.makeText(getApplicationContext(),"자세히 알아보자",Toast.LENGTH_SHORT).show();
//                Intent con = new Intent(getApplicationContext(),Plan4Activity.class);
//                startActivity(con);
//            }
//        });
    }
}
