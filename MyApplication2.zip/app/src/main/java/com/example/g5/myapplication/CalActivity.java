package com.example.g5.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class CalActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cal);

         Button main= findViewById(R.id.main);
         Button plus = findViewById(R.id.plus);
         Button minus = findViewById(R.id.minus);

         main.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                  Intent go = new Intent(getApplicationContext(),MainActivity.class);
                  startActivity(go);

             }
         });

         plus.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 EditText num1 = findViewById(R.id.num1);
                 EditText num2 = findViewById(R.id.num2);

                 String n1 = num1.getText().toString();
                 String n2 = num2.getText().toString();
                 //숫자를 가져와야 계산이 가능한데, 컴퓨터는 우선 모두 스트링으로 가져와서 텍스트로 인식한다.
                 //문자열(String) into integer 하는 부품은 뭐라고 하나? Integer

                 int i1 =  Integer.parseInt(n1);
                 int i2 =  Integer.parseInt(n2);
                            //부품.분석한다(n1을)

                 int total = i1 + i2;
                 //토스트를 띄울건데 여기 int가 들어가서 안뜰거야 그래서 total+""를 이용해서 스트링으로 만들어준다.
                 Toast.makeText(getApplicationContext(),"두수의 합은 : " + total,Toast.LENGTH_SHORT).show();
                 TextView result = findViewById(R.id.result);
                 result.setText("두 수의 합은:" + total);

             }
         });

        minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText num1 = findViewById(R.id.num1);
                EditText num2 = findViewById(R.id.num2);

                String n1 = num1.getText().toString();
                String n2 = num2.getText().toString();
                //숫자를 가져와야 계산이 가능한데, 컴퓨터는 우선 모두 스트링으로 가져와서 텍스트로 인식한다.
                //문자열(String) into integer 하는 부품은 뭐라고 하나? Integer

                int i1 =  Integer.parseInt(n1);
                int i2 =  Integer.parseInt(n2);
                //부품.분석한다(n1을)

                int total = i1 - i2;
                //토스트를 띄울건데 여기 int가 들어가서 안뜰거야 그래서 total+""를 이용해서 스트링으로 만들어준다.
                Toast.makeText(getApplicationContext(),"두수의 차는 : " + total,Toast.LENGTH_SHORT).show();
                TextView result = findViewById(R.id.result);
                result.setText("두 수의 차는:" + total);

            }
        });





    }
}
