package com.example.g5.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        Button login = findViewById(R.id.login);
        Button back = findViewById(R.id.start3);

        login.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                String id1 = "root";
                String pw1 = "1234";

                EditText id2 = findViewById(R.id.id2);
                EditText pw2 = findViewById(R.id.pw);

                String id = id2.getText().toString();
                String pw = pw2.getText().toString();

                if(id.equals(id1) && pw.equals(pw1) ){
                    //조건문을 두개 쓰는경우에는 위와같이 &&으로 쓰면 된다.
                    Intent intent = new Intent(getApplicationContext(),OKActivity.class);
                    startActivity(intent);

                } else {

                    Intent intent = new Intent(getApplicationContext(),NOTActivity.class);
                    startActivity(intent);
                }

            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                startActivity(intent);
            }
        });

    }
}
